#include<stdio.h>
#include<bits/stdc++.h>
#include<math.h>
#include<string.h>
#include<graphics.h>
#define PI 3.14159265

bool dot=false;
char val[20]="";
int mx,my,po=0,ftv;  // po = press option..
double fv=0,lv=0;
double add(double a,double b)
{
    return a+b;
}

double sub(double a,double b)
{
    return a-b;
}

double mult(double a,double b)
{
    return a*b;
}

double div(double a,double b)
{
    return a/b;
}

double mod(int a,int b)
{
    return a%b;
}

double sqr(double a)
{
    return a*a;
}

double root(double a)
{
    return sqrt(a);
}

double logval(double n)
{
    return log(n);
}

long fact(int n)
{
    if(n==0)
    {
        return 1;
    }
    else
    {
        return (n*fact(n-1));
    }
}

void drawCalculator()
{
    rectangle(20,20,360,80);
    settextstyle(11,0,1);

    //------- 1st row -----------

    rectangle(20,100,80,130);
    outtextxy(45,107,"C");
    rectangle(90,100,150,130);
    outtextxy(115,107,"^2");
    rectangle(160,100,220,130);
    outtextxy(175,107,"sqrt");
    rectangle(230,100,290,130);
    outtextxy(255,107,"%");
    rectangle(300,100,360,130);
    outtextxy(330,107,"/");


//-------- 2n row ----------

    rectangle(20,140,80,170);
    outtextxy(45,147,"log");
    rectangle(90,140,150,170);
    outtextxy(115,147,"sin");
    rectangle(160,140,220,170);
    outtextxy(175,147,"cos");
    rectangle(230,140,290,170);
    outtextxy(255,147,"tan");
    rectangle(300,140,360,170);
    outtextxy(330,150,"*");

//------------ 3rd row ----------

    rectangle(20,180,80,210);
    outtextxy(40,187,"exp");
    rectangle(90,180,150,210);
    outtextxy(115,187,"7");
    rectangle(160,180,220,210);
    outtextxy(185,187,"8");
    rectangle(230,180,290,210);
    outtextxy(255,187,"9");
    rectangle(300,180,360,210);
    outtextxy(330,187,"-");

//----- 4th row ----------

    rectangle(20,220,80,250);
    outtextxy(40,227,"pow");
    rectangle(90,220,150,250);
    outtextxy(115,227,"4");
    rectangle(160,220,220,250);
    outtextxy(185,227,"5");
    rectangle(230,220,290,250);
    outtextxy(255,227,"6");
    rectangle(300,220,360,250);
    outtextxy(330,227,"+");

//----- 5th row ----------

    rectangle(20,260,80,290);
    outtextxy(50,267,"!");
    rectangle(90,260,150,290);
    outtextxy(115,267,"1");
    rectangle(160,260,220,290);
    outtextxy(185,267,"2");
    rectangle(230,260,290,290);
    outtextxy(255,267,"3");
    rectangle(300,260,360,330);
    outtextxy(326,287,"=");


//---------- 6th ---------

    rectangle(20,300,80,330);
    outtextxy(50,307,"PI");
    rectangle(90,300,150,330);
    outtextxy(115,307,"0");
    rectangle(160,300,220,330);
    outtextxy(185,307,"00");
    rectangle(230,300,290,330);
    outtextxy(255,307,".");
}

void display(char *str)
{

    settextstyle(8,0,5);
    outtextxy(32,33,str);

}


int main()
{

    initwindow(380,400);
    setbkcolor(BLUE);
    drawCalculator();
    while(true)
    {

        mx = mousex();
        my = mousey();
        drawCalculator();
        if(ismouseclick(WM_LBUTTONDOWN))
        {
            if(mx>20 && mx<80 && my>100 && my<130 )
            {
                printf("C\n");
                strcpy(val,"");
                po=0;
                dot=false;
            }
            else if(mx>90 && mx<150 && my>100 && my<130)
            {
                printf("^2\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        printf("%s\n=>",val);
                        fv=atof(val);
                        printf("%.1f\n",fv);
                        po=7;
                        dot=false;
                        sprintf(val,"(%.1f)^2",fv);
                    }
                }

            }
            else if(mx>160 && mx<220 && my>100 && my<130)
            {
                printf("sqrt\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=6;
                        dot=false;
                        sprintf(val,"sqrt(%.1f)",fv);
                    }
                }

            }
            else if(mx>230 && mx<290 && my>100 && my<130)
            {
                printf("%%\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atoi(val);
                        printf("%.1f",fv);
                        po=5;
                        dot=false;
                        strcpy(val,"");
                    }
                }
            }
            else if(mx>300 && mx<360 && my>100 && my<130)
            {
                printf("/\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=4;
                        dot=false;
                        strcpy(val,"");
                    }
                }
            }
            else if(mx>20 && mx<80 && my>140 && my<170)
            {
                printf("log\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=8;
                        dot=false;
                        sprintf(val,"log(%.1f)",fv);
                    }
                }

            }
            else if(mx>90 && mx<150 && my>140 && my<170)
            {
                printf("sin\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=9;
                        dot=false;
                        sprintf(val,"sin(%.1f)",fv);
                    }
                }

            }
            else if(mx>160 && mx<220 && my>140 && my<170)
            {
                printf("cos\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=10;
                        dot=false;
                        sprintf(val,"cos(%.1f)",fv);
                    }
                }
            }
            else if(mx>230 && mx<290 && my>140 && my<170)
            {
                printf("tan\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=11;
                        dot=false;
                        sprintf(val,"tan(%.1f)",fv);
                    }
                }
            }
            else if(mx>300 && mx<360 && my>140 && my<170)
            {
                printf("*\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=3;
                        dot=false;
                        strcpy(val,"");
                    }
                }

            }
            else if(mx>20 && mx<80 && my>180 && my<210)
            {
                printf("exp\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=12;
                        dot=false;
                        sprintf(val,"exp(%.1f)",fv);
                    }
                }
            }
            else if(mx>90 && mx<150 && my>180 && my<210)
            {
                printf("7\n");
                strcat(val,"7");
            }
            else if(mx>160 && mx<220 && my>180 && my<210)
            {
                printf("8\n");
                strcat(val,"8");
            }
            else if(mx>230 && mx<290 && my>180 && my<210)
            {
                printf("9\n");
                strcat(val,"9");
            }
            else if(mx>300 && mx<360 && my>180 && my<210)
            {
                printf("-\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=2;
                        dot=false;
                        strcpy(val,"");
                    }
                }
            }
            else if(mx>20 && mx<80 && my>220&& my<250)
            {
                printf("pow\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=13;
                        dot=false;
                        strcpy(val,"");
                    }
                }
            }
            else if(mx>90 && mx<160 && my>220&& my<250)
            {
                printf("4\n");
                strcat(val,"4");
            }
            else if(mx>160&& mx<230 && my>220&& my<250)
            {
                printf("5\n");
                strcat(val,"5");
            }
            else if(mx>230 && mx<290 && my>220&& my<250)
            {
                printf("6\n");
                strcat(val,"6");
            }
            else if(mx>300 && mx<360 && my>220&& my<250)
            {
                printf("+\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        fv=atof(val);
                        printf("%.1f",fv);
                        po=1;
                        dot=false;
                        strcpy(val,"");
                    }
                }
            }
            else if(mx>20 && mx<80 && my>260&& my<290)
            {
                printf("!\n");
                if(strlen(val)!=0)
                {
                    if(po==0)
                    {
                        ftv=atoi(val);
                        printf("%d",ftv);
                        po=14;
                        dot=false;
                        sprintf(val,"%d!",ftv);
                    }
                }
            }
            else if(mx>90 && mx<150 && my>260&& my<290)
            {
                printf("1\n");


                strcat(val,"1");
            }
            else if(mx>160&& mx<220 && my>260&& my<290)
            {
                printf("2\n");
                strcat(val,"2");
            }
            else if(mx>230 && mx<290 && my>260&& my<290)
            {
                printf("3\n");
                strcat(val,"3");
            }
            else if(mx>300 && mx<360 && my>260&& my<330)
            {
                printf("=\n");
                if(po==1)
                {
                    lv = atof(val);
                    sprintf(val,"%.1f",add(fv,lv));
                }
                else if(po==2)
                {
                    lv = atof(val);
                    sprintf(val,"%.1f",sub(fv,lv));
                }
                else if(po==3)
                {
                    lv = atof(val);
                    sprintf(val,"%.1f",mult(fv,lv));
                }
                else if(po==4)
                {
                    lv = atof(val);
                    sprintf(val,"%.1f",div(fv,lv));
                }
                else if(po==5)
                {
                    lv = atoi(val);
                    sprintf(val,"%.1f",mod(fv,lv));
                }
                else if(po==6)
                {
                    sprintf(val,"%.1f",root(fv));
                }
                else if(po==7)
                {
                    sprintf(val,"%.1f",sqr(fv));
                }
                else if(po==8)
                {
                    sprintf(val,"%.1f",logval(fv));
                }
                else if(po==9)
                {
                    sprintf(val,"%.1f",sin((PI*fv)/180));
                }
                else if(po==10)
                {
                    sprintf(val,"%.1f",cos((PI*fv)/180));
                }
                else if(po==11)
                {
                    sprintf(val,"%.1f",tan((PI*fv)/180));
                }
                else if(po==12)
                {
                    sprintf(val,"%.1f",exp(fv));
                }
                else if(po==13)
                {
                    lv = atof(val);
                    sprintf(val,"%.1f",pow(fv,lv));
                }
                else if(po==14)
                {
                    sprintf(val,"%ld",fact(ftv));
                }

            }
            else if(mx>20 && mx<80 && my>300&& my<330)
            {
                printf("pi\n");
            }
            else if(mx>90 && mx<150 && my>300&& my<330)
            {
                printf("0\n");
                strcat(val,"0");
            }
            else if(mx>160 && mx<220 && my>300&& my<330)
            {
                printf("00\n");
                strcat(val,"00");
            }
            else if(mx>230&& mx<290 && my>300&& my<330)
            {
                printf(".\n");
                if(dot==false)
                {
                    strcat(val,".");
                    dot = true;
                    printf("In dot.\n");
                }
                else
                {

                    printf("Value : %s ",val);
                }
            }

            clearmouseclick(WM_LBUTTONDOWN);

        }

        display(val);



        delay(100);
        cleardevice();


    }

    getch();
    closegraph();

    return 0;
}
